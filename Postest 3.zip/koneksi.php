<?php
//deklarasi variabel untuk koneksi 
$host="localhost";
$username="root";
$password="";
$databasename="akademik";
//membuat koneksi kedalam databasenya 
$con=@mysqli_connect($host,$username,$password,$databasename);
//mengecek koneksi berhasil atau tidak
if (!$con) {
echo "Error: " . mysqli_connect_error();
exit();
}
?>