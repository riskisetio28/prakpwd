<?php
//memulai session
session_start();
//menghancurkan atau menghapus session
session_destroy();
//menanpilkan informasi pada halaman web berupa Anda telah sukses keluar sistem LOGOUT
echo "Anda telah sukses keluar sistem <b>LOGOUT</b>";
